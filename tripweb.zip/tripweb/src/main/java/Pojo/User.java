package Pojo;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class User {
    private int uid;    //用户id（在页面中不显示）
    private String username;  //用户名
    private String password;  //密码
    private String realName; //真实姓名
    private String phone;   // 限制为11位
    private String sex;   // 男 或 女
    private String userImg;  //用户头像
    private String details;  //用户介绍
    private String newPass;  //新密码

    //无参构造函数
    public User(){}
}


