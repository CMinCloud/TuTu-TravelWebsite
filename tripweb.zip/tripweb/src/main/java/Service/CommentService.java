package Service;

import Dao.Mapper.CommentMapper;
import Pojo.PageBean;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSession;
import util.SqlSessionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CommentService {
    // 在Service中只构建一次sqlSession对象,已设置为自动提交
    private SqlSession sqlSession = SqlSessionUtils.getSqlSession();
    // 获取mapper
    private CommentMapper commentMapper = sqlSession.getMapper(CommentMapper.class);

    /**
     * 1.查看评论
     *
     * @return 评论列表（用户名，评论内容，评论时间，点赞数）
     */
    public ArrayList<Map<String, Object>> selectComments(int sid, int nid) {
        ArrayList<Map<String, Object>> maps = commentMapper.selectComments(sid, nid);
        return maps;
    }

    /**
     * 1.1 返回分页查询所需的数据:分页数据结果集(map存放)
     */
    public PageBean<Map<String, Object>> selectCommentsByPage(int sid, int nid, int currentPage, int pageSize) {
//         (当前页-1)*页面显示条数 = 开始索引
        int begin = (currentPage - 1) * pageSize;
//        获取评论数据
        ArrayList<Map<String, Object>> maps = commentMapper.selectCommentsByPage(sid, nid, begin, pageSize);
//        封装为pageBean
        PageBean<Map<String, Object>> CommentsInfo = new PageBean<Map<String, Object>>();
//        调用接口查询评论总条目数
        int total = commentMapper.selectAmountOfComments(sid, nid);
//        封装评论列表和总条目数
        CommentsInfo.setTotalCount(total);
        CommentsInfo.setNoteArray(maps);
        return CommentsInfo;
    }


    /**
     * 2.1新增旅行服务评论
     */
    public int InsertServiceComment(Map map) {
        int i = commentMapper.InsertServiceComment(map);
        return i;
    }

    /**
     * 2.2新增游记评论
     */
    public int InsertNoteComment(Map map) {
        int i = commentMapper.InsertNoteComment(map);
        return i;
    }

    /**
     * 3.删除评论
     */
    public int DeleteCommentByCid(int cid) {
        int i = commentMapper.DeleteCommentByCid(cid);
        return i;
    }
}
