package Service;

import Dao.Mapper.CollectionMapper;
import Pojo.Collection;
import Pojo.PageBean;
import Pojo.Service;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import util.SqlSessionFactoryUtils;

import java.util.List;

public class CollectionService {
    SqlSessionFactory factory = SqlSessionFactoryUtils.getSqlSessionFactory();

    /**
     * 根据用户id查询收藏
     *
     * @param
     * @param uid
     * @return
     */
//    public ArrayList<Collection> collectionListByUid(int uid){
//        ArrayList<Collection> collections = collectionMapper.collectionListByUid(uid);
//        return collections;
//    }
    public List<Collection> collectionShow(int uid) {
        SqlSession sqlSession = factory.openSession();
        // 获取mapper
        CollectionMapper collectionMapper = sqlSession.getMapper(CollectionMapper.class);
        List<Collection> collections = collectionMapper.collectionShow(uid);
        sqlSession.close();
        return collections;
    }

    public void collectionDelete(Service service) {
        SqlSession sqlSession = factory.openSession();
        // 获取mapper
        CollectionMapper collectionMapper = sqlSession.getMapper(CollectionMapper.class);
        collectionMapper.collectionDelete(service);
        sqlSession.commit();
        sqlSession.close();
    }

    public PageBean<Collection> collectionSelectByPage(int uid, int currentPage, int pageSize) {
        SqlSession sqlSession = factory.openSession();
        CollectionMapper collectionMapper = sqlSession.getMapper(CollectionMapper.class);
        int begin = (currentPage - 1) * 5;
        int size = pageSize;
        List<Collection> rows = collectionMapper.collectionSelectByPage(uid, begin, size);
        int totalCount = collectionMapper.collectionCount(uid);
        PageBean<Collection> pageBean = new PageBean<>();
        pageBean.setRows(rows);
        pageBean.setTotalCount(totalCount);
        sqlSession.close();
        return pageBean;
    }

    public int collectionCount(int uid) {
        SqlSession sqlSession = factory.openSession();
        CollectionMapper mapper = sqlSession.getMapper(CollectionMapper.class);
        int count = mapper.collectionCount(uid);
//        System.out.println("service"+count);
        return count;
    }


    /**
     * 用户新增收藏
     */
    public int insertCollection(int uid, int sid, String date) {
        SqlSession sqlSession = factory.openSession();
        CollectionMapper mapper = sqlSession.getMapper(CollectionMapper.class);
//        调用mapper接口新增收藏
        int count = mapper.insertCollection(uid, sid, date);
//        返回更新数，更新数为1则代表添加成功
        //提交事务
        sqlSession.commit();
        sqlSession.close();
        return count;
    }
}

