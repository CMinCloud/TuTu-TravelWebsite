package Service;

import Dao.Mapper.NoteMapper;
import Pojo.*;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import util.SqlSessionFactoryUtils;
import util.SqlSessionUtils;

import java.util.ArrayList;
import java.util.List;

public class NoteService {
    // 在Service中只构建一次sqlSession对象,已设置为自动提交
    SqlSession sqlSession = SqlSessionUtils.getSqlSession();
    // 获取mapper
    private NoteMapper noteMapper = sqlSession.getMapper(NoteMapper.class);

    SqlSessionFactory factory = SqlSessionFactoryUtils.getSqlSessionFactory();



    /***
     *获取用户id
     * 根据用户id增添游记头
     */
    public int addNoteTitle(Note note){
        int count=0;
        count = noteMapper.addNoteTitle(note);
        return count;
    }

    /*
     * 给正在发布的游记添加模块的方法
     * 找到当前游记表里面的最后一个id     selectLastNoteId()
     * 根据游记id添加对应的游记模块
     * */

    public int addNoteModule(NoteModule noteModule){
        int count=0;
        count= noteMapper.addNoteModule(noteModule);
        return count;
    }
    /*
    * 查询当前游记id里面的最后一个id
    * */
    public int selectLastNoteId(){
        int LastNoteId;
        LastNoteId=noteMapper.selectLastNoteId();
        return LastNoteId;
    }

    /*
    获取当前用户id
    * 根据当前用户id查询游记id的集合
    * */
    public ArrayList<Integer> NoteIds(int uid){
        ArrayList<Integer> arrayList;
        arrayList=noteMapper.NoteIds(uid);
        return arrayList;
    }

    /*
    * 根据游记id 在游记表里面 来查找出对应的游记对象
    * */
    public Note NoteDetails(int note_id){
        Note note = noteMapper.NoteDetails(note_id);
        return note;
    }
    /*
     * 游记详情页面的相关展示
     * 根据
     * ArrayList<Integer> NoteIds(@Param("uid") int uid);方法查询出游记id的集合
     * 遍历集合
     * 根据游记id在游记模块表里面查询模块的详情信息
     *
     * */
    public ArrayList<NoteModule> NoteModuleDetails(int note_id){
        ArrayList<NoteModule> noteModules = new ArrayList<>();
        noteModules=noteMapper.NoteModuleDetails(note_id);
        return noteModules;
    }

    /*用户处理*/
    public Pojo.User UserMessage(int uid){
        User user = noteMapper.UserMessage(uid);
        return user;
    }

    /*查询游记表里面的所有id集合*/
    public ArrayList<Integer> NoteIdList(){
        ArrayList<Integer> arrayList = noteMapper.NoteIdsList();
        return arrayList;
    }

    /*根据游记id在游记表里面查询对应的用户id*/
    public int UserId(int note_id){
        int userId = noteMapper.UserId(note_id);
        return userId;
    }

    /*根据游记id获取游记模块表里面的所有游记模块的id集合*/
    public ArrayList<Integer> ModuleIds(int note_id){
        ArrayList<Integer> moduleIds = noteMapper.ModuleIds(note_id);
        return moduleIds;
    }

    /*根据模块id查询模块对象*/
    public NoteModule Module(int module_id){
        NoteModule module = noteMapper.Module(module_id);
        return module;
    }

    /*查询游记表里面的id总数*/
    public int findTotalCount(String note_title){
        int totalCount = noteMapper.findTotalCount(note_title);
        return totalCount;
    }

    public ArrayList<Integer> PageNoteIds(String note_title,int start,int pageSize){
        /*获取指定页面的id集合*/
        ArrayList<Integer> pageNoteIds = noteMapper.PageNoteIds(note_title,start, pageSize);
        return pageNoteIds;
    }

    /*该方法用于封装游记模块集合对象*/
    public PageBean<NoteModuleDetail> pageQuery(String note_title,int currentPage,int pageSize){
        /*创建一个对象集合*/
        ArrayList<NoteModuleDetail> NoteArray=new ArrayList<NoteModuleDetail>();

        /*封装pageBean*/
        PageBean<NoteModuleDetail> pb = new PageBean<NoteModuleDetail>();
        /*设置当前页码*/
        pb.setCurrentPage(currentPage);
        /*设置每页显示的条数*/
        pb.setPageSize(pageSize);
        /*设置总记录数*/
        int totalCount=noteMapper.findTotalCount(note_title);
        pb.setTotalCount(totalCount);
        /*设置总页数 =总记录数/每页显示的条数*/
        int totalPage=totalCount%pageSize==0?totalCount/pageSize:(totalCount/pageSize)+1;
        pb.setTotalPage(totalPage);

        /*设置当前页显示的数据集合*/
        int start=(currentPage-1)*pageSize;/*开始的记录数*/
        /*获取当前页面的游记id集合*/
        ArrayList<Integer> pageNoteIds = PageNoteIds(note_title,start, pageSize);
        System.out.println(pageNoteIds);
        /*循环遍历当前页游记id*/
        for (int nid : pageNoteIds) {
            /*根据游记id查找出对应的用户id*/
            int userId = UserId(nid);
            /*根据用户id获取对应的用户对象*/
            User user = UserMessage(userId);
            /*根据游记id,在游记表里面查找出对应的游记对象*/
            Note note = NoteDetails(nid);
            NoteModuleDetail noteModuleDetail = new NoteModuleDetail(note.getNote_id(), note.getNote_title(), note.getUser_id(), note.getNote_date(), note.getNote_img(), note.getComment_like(), note.getPlaydays(), note.getRecommend(),
                    user.getUsername(), user.getUserImg());
            NoteArray.add(noteModuleDetail);
        }
        pb.setNoteArray(NoteArray);
        return pb;
    }


    /*游记删除模块*/
    public void deleteModule(int note_id){
        int count1=0;
        int count2=0;
        /*删除游记id对应的游记头*/
        count1 = noteMapper.deleteModule(note_id);
        /*删除游记id对应的游记模块*/
        count2 = noteMapper.deleteTitle(note_id);
        if(count1==1 & count2==1){
            System.out.println("取消发送成功");
        }
    }


    /**
     * 刘怀键------------------------------------------------------------------
     */
    public void noteDelete(int noteId){
        SqlSession sqlSession = factory.openSession();
        // 获取mapper
        NoteMapper noteMapper = sqlSession.getMapper(NoteMapper.class);
        noteMapper.noteDelete(noteId);
        sqlSession.commit();
        sqlSession.close();
    }
    public PageBean<Note> noteSelectByPage(int uid , int currentPage, int pageSize){
        SqlSession sqlSession = factory.openSession();
        NoteMapper noteMapper = sqlSession.getMapper(NoteMapper.class);
        int begin = (currentPage-1)*5;
        int size = pageSize;
        List<Note> rows = noteMapper.SelectByPage(uid,begin,size);
        int totalCount = noteMapper.noteCount(uid);
        PageBean<Note> pageBean = new PageBean<>();
        pageBean.setRows(rows);
        pageBean.setTotalCount(totalCount);
        System.out.println(rows);
        sqlSession.close();
        return  pageBean;
    }
    public PageBean<Note> noteAllSelectByPage(int currentPage, int pageSize){
        SqlSession sqlSession = factory.openSession();
        NoteMapper noteMapper = sqlSession.getMapper(NoteMapper.class);
        int begin = (currentPage-1)*5;
        int size = pageSize;
        List<Note> rows = noteMapper.allSelectByPage(begin,size);
        int totalCount = noteMapper.noteAllCount();
        PageBean<Note> pageBean = new PageBean<>();
        pageBean.setRows(rows);
        pageBean.setTotalCount(totalCount);
        System.out.println(rows);
        sqlSession.close();
        return  pageBean;
    }
    public int Count(int uid){
        SqlSession sqlSession = factory.openSession();
        NoteMapper mapper = sqlSession.getMapper(NoteMapper.class);
        int count = mapper.noteCount(uid);
        System.out.println("service"+count);
        return count;
    }


}
