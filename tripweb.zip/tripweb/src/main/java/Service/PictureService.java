package Service;

import Dao.Mapper.PictureMapper;
import Pojo.Picture;
import org.apache.ibatis.session.SqlSession;
import util.SqlSessionUtils;

import java.util.ArrayList;

public class PictureService {
    // 在Service中只构建一次sqlSession对象,已设置为自动提交
    private SqlSession sqlSession = SqlSessionUtils.getSqlSession();
    private PictureMapper pictureMapper = sqlSession.getMapper(PictureMapper.class);


}
