package Service;

import Dao.Mapper.OrderMapper;
import Dao.Mapper.ServiceMapper;
import Pojo.Order;
import Pojo.PageBean;
import Pojo.Service;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import util.SqlSessionFactoryUtils;
import util.SqlSessionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class OrderService {
    // 在Service中只构建一次sqlSession对象,已设置为自动提交
    private SqlSession sqlSession = SqlSessionUtils.getSqlSession();
    // 获取mapper
    private OrderMapper orderMapper = sqlSession.getMapper(OrderMapper.class);
    private ServiceMapper serviceMapper = sqlSession.getMapper(ServiceMapper.class);
    SqlSessionFactory factory = SqlSessionFactoryUtils.getSqlSessionFactory();
    /**
     * 1.插入订单（需要先判断是否已提交该订单）
     */
    public int insertOrder(Order order) {
        int count = 0; //记录修改行数
        count = orderMapper.insertOrder(order);
        return count;
    }
    /**
     * 2.查询我的订单
     */
    public ArrayList<Map<String, Object>> selectOrderByUid(int uid) {
        ArrayList<Map<String, Object>> orders = orderMapper.selectOrderByUid(uid);
        return orders;
    }

    /**
     * 3.取消订单
     */
    public int deleteOrder(int uid,int sid){
        int i = orderMapper.deleteOrder(uid,sid);
        return i;
    }

    /**
     * 4.根据sid获取service对象
     */
    public Map<String,Object> SelectServiceBySid(int sid){
        Map<String,Object> map = orderMapper.SelectServiceBySid(sid);
        return  map;
    }


    /**
     * 刘怀键-------------------
     */
    public PageBean<Order> SelectByPage(int uid , int currentPage , int pageSize){
        SqlSession sqlSession = factory.openSession();
        OrderMapper orderMapper = sqlSession.getMapper(OrderMapper.class);
        int begin = (currentPage-1)*pageSize;
        int size = pageSize;
        int total = orderMapper.orderCount(uid);
        List<Order> rows = orderMapper.SelectByPage(uid, begin, size);
        PageBean<Order> pageBean = new PageBean<>();
        pageBean.setTotalCount(total);
        pageBean.setRows(rows);
        sqlSession.close();
        return pageBean;
    }
    public void orderDelete(Order order){
        SqlSession sqlSession = factory.openSession();
        // 获取mapper
        OrderMapper orderMapper = sqlSession.getMapper(OrderMapper.class);
        orderMapper.orderDelete(order);
        sqlSession.commit();
        sqlSession.close();
    }
}
