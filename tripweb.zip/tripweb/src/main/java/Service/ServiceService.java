package Service;

import Dao.Mapper.ServiceMapper;
import Pojo.*;
import org.apache.ibatis.session.SqlSession;
import util.SqlSessionUtils;

import java.util.ArrayList;

public class ServiceService {
    private SqlSession sqlSession = SqlSessionUtils.getSqlSession();
    // 获取mapper
    private ServiceMapper serviceMapper = sqlSession.getMapper(ServiceMapper.class);


    //    #1.根据service 的id查询出所有的对应图片id
    public ArrayList<Integer> imgsList(int service_id){
        ArrayList<Integer> imgsList = serviceMapper.imgsList(service_id);
        return imgsList;
    }

    //#2.根据图片id查询出对应的图片路径
    public String imgSrc(int pic_id){
        String imgSrc = serviceMapper.imgSrc(pic_id);
        return imgSrc;
    }

//#3.将图片路径存到集合里面
    //#4.查询出所有的service_id
    public ArrayList<Integer> serviceIds(){
        ArrayList<Integer> serviceIds = serviceMapper.serviceIds();
        return serviceIds;
    }

    //#5.根据service_id查询出对应的service详细信息
    public Service serviceDetail(int service_id){
        Service serviceDetail = serviceMapper.serviceDetail(service_id);
        ArrayList<String> imgsSrcList = new ArrayList<>();
        /*根据服务id找到所有的图片id*/
        ArrayList<Integer> imgsIdList = imgsList(service_id);
        /*遍历图片id,找到对应的图片路径*/
        for (int imgId:imgsIdList) {
            /*根据图片id找到对应的图片路径*/
            String imgSrc = imgSrc(imgId);
            /*将图片路径放在图片路径集合里面*/
            imgsSrcList.add(imgSrc);
        }
        serviceDetail.setServiceImgs(imgsSrcList);
        return serviceDetail;
    }


    public ArrayList<Integer> PageServiceIds(String service_name,int start,int pageSize){
        /*获取指定页面的id集合*/
        ArrayList<Integer> pageNoteIds = serviceMapper.PageNoteIds(service_name,start, pageSize);
        return pageNoteIds;
    }


    public int findTotalCount(String service_name){
        int count = serviceMapper.findTotalCount(service_name);
        return count;
    }

    /*该方法用于封装景点集合对象*/
    public PageBean<Service> pageQuery(String service_name, int currentPage, int pageSize){
        /*创建一个对象集合*/
        ArrayList<Service> ServiceArray=new ArrayList<Service>();


        /*封装pageBean*/
        PageBean<Service> pb = new PageBean<Service>();
        /*设置当前页码*/
        pb.setCurrentPage(currentPage);
        /*设置每页显示的条数*/
        pb.setPageSize(pageSize);
        /*设置总记录数*/
        int totalCount=serviceMapper.findTotalCount(service_name);
        pb.setTotalCount(totalCount);
        /*设置总页数 =总记录数/每页显示的条数*/
        int totalPage=totalCount%pageSize==0?totalCount/pageSize:(totalCount/pageSize)+1;
        pb.setTotalPage(totalPage);

        /*设置当前页显示的数据集合*/
        int start=(currentPage-1)*pageSize;/*开始的记录数*/
        /*获取当前页面的游记id集合*/
        ArrayList<Integer> pageServiceIds = PageServiceIds(service_name,start, pageSize);
        System.out.println(pageServiceIds);
        /*循环遍历当前页景点id*/
        for (int sid : pageServiceIds) {
            /*根据景点id找到对应的景点对象*/
            Service serviceDetail = serviceMapper.serviceDetail(sid);
            /*一个景点对象对应一个景点集合，所以放在一起*/
            ArrayList<String> imgsSrcList = new ArrayList<>();
            /*根据服务id找到所有的图片id*/
            ArrayList<Integer> imgsIdList = imgsList(sid);
            /*遍历图片id,找到对应的图片路径*/
            for (int imgId:imgsIdList) {
                /*根据图片id找到对应的图片路径*/
                String imgSrc = imgSrc(imgId);
                /*将图片路径放在图片路径集合里面*/
                imgsSrcList.add(imgSrc);/*景点里面的图片集合*/
            }
            /*将图片集合设置给景点对象*/
            serviceDetail.setServiceImgs(imgsSrcList);
            /*再将景点对象放在集合里面*/
            ServiceArray.add(serviceDetail);
        }
        pb.setNoteArray(ServiceArray);
        return pb;
    }









}
