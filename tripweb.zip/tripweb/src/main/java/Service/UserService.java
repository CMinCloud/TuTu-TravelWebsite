package Service;

import Pojo.Safe;
import Pojo.User;
import Dao.Mapper.UserMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import util.SqlSessionFactoryUtils;
import util.SqlSessionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class UserService {
    // 在Service中只构建一次sqlSession对象,已设置为自动提交
    private SqlSession sqlSession = SqlSessionUtils.getSqlSession();
    private UserMapper userMapper = sqlSession.getMapper(UserMapper.class);


    SqlSessionFactory factory = SqlSessionFactoryUtils.getSqlSessionFactory();

    /**
     * 根据uid获取用户信息
     *
     * @param uid
     * @return
     */
    public User selectUserByUid(int uid) {

        //注册接口类，当Mapper.xml文件与Mapper.java同级时会显示已注册
        // factory.getConfiguration().addMapper(UserMapper.class);
        // 获得mapper

        // 使用mapper执行业务
        User user = userMapper.selectUserByUid(uid);
        return user;
    }

    /**
     * 根据用户登录信息返回用户详细信息（登陆处理）
     *
     * @param username
     * @param password
     * @return
     */

    public User SelectIdByLoginInfo(String username, String password) {
        User user = userMapper.SelectIdByLoginInfo(username, password);
        if (user == null) {
            System.out.println("不存在该用户!");
        }
        return user;
    }

    /**
     * 找回密码：
     * 根据手机号获取用户密保信息
     */
    public ArrayList<Map<String, String>> getSecretByPhone(String phoneNumber){
        ArrayList<Map<String, String>> secretByPhone = userMapper.getSecretByPhone(phoneNumber);
        if(secretByPhone == null){
            System.out.println("service：未获取到密保信息");
            return null;
        }
        return  secretByPhone;
    }

    /**
     * 找回密码：
     * 设置新密码
     */
    public int SetNewPassword(int uid,String newPassword){
        int i = userMapper.SetNewPassword(uid, newPassword);
        return i;
    }

    /**
     * 查询用户表中该手机号的用户数,只有1和0两种，不为1则不存在
     */
    public int CountUserByPhone(String phoneNumber){
        int count = userMapper.CountUserByPhone(phoneNumber);
        return count;
    }

    public boolean regist(User user){
        SqlSession sqlSession = factory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        System.out.println(user.getUsername());
        User u = userMapper.selectUserByName(user.getUsername());
        System.out.println(u);
        if (u != null){
            /*注册失败*/
            return false;
        }
        userMapper.registerUser(user);
        sqlSession.commit();
        sqlSession.close();
        return true;
    }
    public void change(User user){
        SqlSession sqlSession = factory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        System.out.println(user);
        userMapper.change(user);
        sqlSession.commit();
        sqlSession.close();
    }
    public User userShow(int uid){
        SqlSession sqlSession = factory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        User u = userMapper.userShow(uid);
        sqlSession.close();
        return u;
    }

    public boolean reset(User user) {
        SqlSession sqlSession = factory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        String password = userMapper.getPassword(user);
        System.out.println(password);
        System.out.println(password.equals(user.getPassword()));
        if(password.equals(user.getPassword())){
            userMapper.reset(user);
            sqlSession.commit();
            sqlSession.close();
            return true;
        }else{
            sqlSession.close();
            return false;
        }
    }
    public boolean addSafe(List list){
        SqlSession sqlSession = factory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        System.out.println("service中"+list);
        Safe s = (Safe) list.get(0);
        if(userMapper.findSafe(s.getUid())){
            sqlSession.close();
            return false;
        }
        for(int i = 0 ; i <3 ; i++){
           s = (Safe) list.get(i);
            System.out.println("uid为"+s.getUid()+"qs为"+s.getQuestion()+"as为"+s.getAnswer());
            System.out.println(s);
            userMapper.addSafe(s);
            sqlSession.commit();
        }
        sqlSession.close();
        return true;


    }
}
