package Dao.Mapper;

import Pojo.Note;
import Pojo.NoteModule;
import Pojo.NoteModuleDetail;
import Pojo.User;
import org.apache.ibatis.annotations.*;

import java.util.ArrayList;
import java.util.List;

public interface NoteMapper {

    /*获取用户id？
    * 根据用户id增添游记头
    * */
    @Insert("insert into tripweb.t_note(note_title,user_id,note_date,note_img,playdays,recommend) values " +
            "(#{note_title},#{user_id},#{note_date},#{note_img},#{playdays},#{recommend})")
    int addNoteTitle(Note note);

    /*
    * 查询当前游记表id里面的最后一个id,用于添加模板的时候使用
    *
    * */
    @Select("select t_note.note_id from t_note order by note_id desc limit 1")
    int selectLastNoteId();


    /*
     *根据NoteMapper接口里面的selectLastNoteId()方法返回值获取游记id
     * 对当前游记添加一个模块
     * */
    @Insert("insert into t_notemodule(module_name,content,module_img,note_id) values( #{module_name},#{content},#{module_img},#{note_id})")
    int addNoteModule(NoteModule noteModule);



    /*- 游记浏览模块展示方法 -*/
    /*
     * 获取当前用户id？？？？
     * 根据当前用户id查询出游记id的集合
     * */
    /*这里的 uid 需要根据user类对象里面的uid进行切换*/
    @Select("select note_id from t_note where user_id = #{uid}")
    ArrayList<Integer> NoteIds(@Param("uid") int uid);



    /*
    * ----遍历------上面查询出来的游记id集合，
    * 根据游记id 在游记表里面 来查找出对应的游记对象
    * */
    @Select("select * from t_note where note_id = #{note_id}")
    Note NoteDetails(@Param("note_id") int note_id);



    /*----------------------------------------------------------------------------*/

    /*
    用户处理
    根据session获取当前用户id,根据用户id查找到用户的头像和用户的username
    * */
    @ResultMap("UserResultMap")
    @Select("select * from t_user where user_id = #{user_id}")
    User UserMessage(@Param("user_id") int uid);

    /*----------------------------------------------------------------------------*/




/*------------------------------NoteModule-----------------------------------------*/







    /*
    * 游记详情页面的相关展示
    * 根据
    * ArrayList<Integer> NoteIds(@Param("uid") int uid);方法查询出游记id的集合
    * 遍历集合
    * 根据游记id在游记模块表里面查询模块的详情信息
    *
    * */
    @Select("select module_name,content,note_id,module_img from t_notemodule where note_id = #{note_id}")
    ArrayList<NoteModule> NoteModuleDetails(@Param("note_id") int note_id);



/*------------------------------NoteModule-----------------------------------------*/



//    查询游记表里面的所有游记id
    @Select("select note_id from t_note")
    ArrayList<Integer> NoteIdsList();




    /*根据游记id在游记表里面查询出对应的用户id*/
    @Select("select user_id from t_note where note_id = #{note_id}")
    int UserId(@Param("note_id") int note_id);



    /*根据游记id获取游记模块表里面的所有游记模块的id集合*/
    @Select("select module_id from t_notemodule where note_id=#{note_id}")
    ArrayList<Integer> ModuleIds(int note_id);


    /*根据模块id查询模块对象*/
    @Select("select module_id,module_name,content,note_id,module_img from t_notemodule where module_id=#{module_id}")
    NoteModule Module (int module_id);



    /*查询游记表里面的id总数*/
    @Select("select count(*) from t_note where note_title like '%${note_title}%' ")
    int findTotalCount(@Param("note_title") String note_title);


    /*获取游记表里面对应页的id集合*/
    @Select("select note_id from t_note where note_title like '%${note_title}%' limit #{start},#{pageSize}")
    ArrayList<Integer> PageNoteIds(@Param("note_title") String note_title,@Param("start") int start,@Param("pageSize") int pageSize);


//    delete from t_notemodule where note_id=1

//    delete from t_note where note_id=1

    /*删除游记模块部分*/
    @Delete("delete from t_notemodule where note_id = #{note_id}")
    int deleteModule(@Param("note_id") int note_id);

    /*删除游记头里面的最后一个游记id*/
    @Delete("delete from t_note where note_id=#{note_id}")
    int deleteTitle(@Param("note_id") int note_id);

    /**
     * 刘怀键--------------------------------------------------------
     */


    /**
     * 分页展示
     * @param uid       用户id
     * @param begin     当前页数
     * @param rows      每页展示页数
     * @return          note
     */
    List<Note> SelectByPage(@Param("uid") int uid, @Param("begin") int begin, @Param("rows") int rows);

    /**
     * 统计订单数
     * @param uid 用户id
     * @return  返回订单数
     */
    @Select("select count(*) from t_note where user_id = #{uid}")
    int noteCount(int uid);

    /**
     * 删除订单
     * @param nid   对应旅游服务id
     */
    @Delete("delete from t_note where note_id = #{nid};")
    void noteDelete(int nid);

    List<Note> allSelectByPage(@Param("begin") int begin, @Param("rows") int rows);

    @Select("select count(*) from t_note")
    int noteAllCount();
}
