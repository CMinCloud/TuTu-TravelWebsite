package Dao.Mapper;

import Pojo.Picture;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;

import java.util.ArrayList;

public interface PictureMapper {

}
