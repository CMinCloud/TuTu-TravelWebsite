package Dao.Mapper;

import Pojo.Note;
import Pojo.Service;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;

import java.util.ArrayList;
import java.util.Map;

public interface ServiceMapper {

    /*#景点模块页面：查询所有的景点，封装成集合对象，遍历集合里面的对象*/
//    @Select("select * from t_service ")
//    ArrayList<Service> serviceModules();


//    #1.根据service 的id查询出所有的对应图片id
//    select pic_id from t_pic where service_id=1;
    @Select("select pic_id from t_pic where service_id=#{service_id}")
    ArrayList<Integer> imgsList(int service_id);

//#2.根据图片id查询出对应的图片路径
//    select pic_src from t_pic where pic_id=1;
    @Select("select pic_src from t_pic where pic_id=#{pic_id}")
     String imgSrc(int pic_id);

//#3.将图片路径存到集合里面

//#4.查询出所有的service_id
//    select service_id from t_service;
    @Select(" select service_id from t_service")
    ArrayList<Integer> serviceIds();

//#5.根据service_id查询出对应的service详细信息
//    select * from t_service where service_id=1;
     @Select("select * from t_service where service_id=#{service_id}")
     Service serviceDetail(int service_id);


    /*获取游记表里面对应页的id集合*/
    @Select("select service_id from t_service where service_name like '%${service_name}%' limit #{start},#{pageSize}")
    ArrayList<Integer> PageNoteIds(@Param("service_name") String service_name,@Param("start") int start,@Param("pageSize") int pageSize);



    /*查询service表里面的id总数*/
    @Select("select count(*) from t_service where service_name like '%${service_name}%' ")
    int findTotalCount(@Param("service_name") String service_name);


}
