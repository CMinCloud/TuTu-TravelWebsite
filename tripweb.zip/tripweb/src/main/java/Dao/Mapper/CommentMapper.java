package Dao.Mapper;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;

import java.util.ArrayList;
import java.util.Map;

/*评论模块：
 1.获取评论列表(（用户名，评论内容，评论时间，点赞数）)
 2.在个人中心-我的评论下（可不用区分类型）：
        查询我的评论（评论类型，旅游服务名称/游记名称，评论时间）
 3.在评论区下发表评论(评论对象)1
    3.1.游记评论  sid=0
    3.2.旅行服务评论 nid=0
 4.在个人中心-我的评论处删除评论,根据comment_id进行删除
   */

public interface CommentMapper {

    /**
     * 1.获取评论列表(（用户名，评论内容，评论时间)
     * 游记评论
     */
    ArrayList<Map<String, Object>> selectComments(@Param("sid") int sid, @Param("nid") int nid);

    /**
     * 1.1使用分页功能获取评论列表(用户名，评论内容，评论时间)
     * 旅游服务评论
     */
    ArrayList<Map<String, Object>> selectCommentsByPage(@Param("sid") int sid, @Param("nid") int nid,
                                                        @Param("begin") int begin, @Param("size") int size);

    /**
     * 1.2查询目标评论的数量(分页查询)
     */
    int selectAmountOfComments(@Param("sid") int sid,@Param("nid") int nid);


    /**
     * 2.1添加旅行服务评论
     */
    @Insert("insert into t_comment(user_id,service_id,comment_type,content,comment_date)" +
            "values(#{uid},#{sid},#{type},#{content},#{date})")
    int InsertServiceComment(Map map);

    /**
     * 2.2添加游记评论
     */
    @Insert("insert into t_comment(user_id,note_id,comment_type,content,comment_date)" +
            "values(#{uid},#{nid},#{type},#{content},#{date})")
    int InsertNoteComment(Map map);

    /**
     * 3.删除评论(管理员登陆后，点击评论区的删除按钮，即可删除该评论)
     */
    @Delete("delete from t_comment where comment_id = #{cid}")
    int DeleteCommentByCid(int cid);
}
