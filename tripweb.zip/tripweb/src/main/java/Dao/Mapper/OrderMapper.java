package Dao.Mapper;

import Pojo.Order;
import Pojo.Service;
import org.apache.ibatis.annotations.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/*订单模块：
    1.新增订单(用户id，旅行服务id，出行日期，数量<=3，总价)
    2.个人中心-我的订单：查询(旅行服务名称，出行日期，数量，总价)
    3.取消订单(根据uid和sid删除)
    4.修改订单出行日期（日期>=3天）,待商议界面格式*/
public interface OrderMapper {
    /**
     * 1.添加订单
     */
    @Insert("insert into t_order values(#{uid},#{sid},#{orderDate},#{amount},#{total})")
    int insertOrder(Order order);

    /**
     * 2.查询我的订单
     */
    ArrayList<Map<String,Object>> selectOrderByUid(int uid);

    /**
     * 3.取消订单
     */
    @Delete("delete from t_order where user_id = #{uid} and service_id=#{sid}")
    int deleteOrder(@Param("uid") int uid, @Param("sid") int sid);

    /**
     * 4.在订单界面显示旅游服务信息
     */
    @Select("select service_name,price,service_address,service_img from t_service where service_id = #{sid}")
    Map<String,Object> SelectServiceBySid(int sid);

    /**
     * 刘怀键---------------------------------------------------------------
     */
    /**
     * 分页展示
     * @param uid       用户id
     * @param begin     当前页数
     * @param rows      每页展示页数
     * @return          order
     */
    List<Order> SelectByPage(@Param("uid") int uid, @Param("begin") int begin, @Param("rows") int rows);

    /**
     * 统计订单数
     * @param uid 用户id
     * @return  返回订单数
     */
    @Select("select count(*) from t_order where user_id = #{uid}")
    int orderCount(int uid);

    /***
     * 删除订单
     * @param order
     */
//    @Delete("delete from t_order where service_id = #{sid};")

    void orderDelete(@Param("order") Order order);
}
