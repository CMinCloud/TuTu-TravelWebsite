package Dao.Mapper;


import Pojo.Safe;
import Pojo.User;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.ArrayList;
import java.util.Map;

public interface UserMapper {

    /**
     * 根据uid获取用户信息
     *
     * @param uid
     * @return
     */
    User selectUserByUid(int uid);

    /**
     * 根据登录信息返回用户对象，如果对象存在则登陆成功》》并将用户信息返回给浏览器
     * 当参数为多个时，需要添加param与xml中字段名称进行匹配
     */
    @Select("select * from t_user where username = #{username} and PASSWORD = #{password}")
    @ResultMap("userResultMap")
    User SelectIdByLoginInfo(@Param("username") String username, @Param("password") String password);

    /**
     * 找回密码：
     * 根据手机号获取用户密保信息
     */
    @Select("select t_user.user_id,USERNAME,question,answer from t_secretinfo,t_user where t_user.user_id = t_secretinfo.user_id and phone = #{phone}")
    ArrayList<Map<String, String>> getSecretByPhone(@Param("phone") String phoneNumber);

    /**
     * 查询用户表中该手机号的用户数,只有1和0两种，不为1则不存在
     */
    @Select("select count(*) from t_user where phone = #{phone}")
    int CountUserByPhone(@Param("phone") String phoneNumber);

    /**
     * 密保验证成功后修改密码
     */
    @Update("update t_user set PASSWORD = #{newPassword} where user_id = #{uid}")
    int SetNewPassword(@Param("uid") int uid,@Param("newPassword") String newPasswd);

    /**
     * 刘怀键-------------------------------------------------------
     */
    @Select("select * from  t_user where USERNAME = #{username}")
    @ResultMap("userResultMap")
    User selectUserByName(String username);


    void registerUser(@Param("user") User user);

    void change(@Param("user") User user);

    @Select("select * from t_user where user_id = #{uid};")
    User userShow(int uid);


    String getPassword(@Param("user") User user);

    void reset(@Param("user") User user);


    boolean findSafe(int uid);

    void addSafe(@Param("safe") Safe safe);
}
