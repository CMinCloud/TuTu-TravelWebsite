package Dao.Mapper;

import Pojo.Collection;
import Pojo.PageBean;
import Pojo.Service;
import org.apache.ibatis.annotations.*;

import java.util.ArrayList;
import java.util.List;

public interface CollectionMapper {


    /**
     * 根据用户id查询该用户的收藏
     * @param uid
     * @return
     */

    List<Collection> collectionShow(int uid);

//    @Delete("Delete from t_collection where service_id = #{serviceId}")
    void collectionDelete(@Param("service") Service service);


    List<Collection> collectionSelectByPage(@Param("uid") int uid,@Param("begin") int begin, @Param("rows") int rows);

    @Select("select count(*) from t_collection where user_id = #{uid}")
    int collectionCount(int uid);

    /**
     * 用户新增收藏
     * 需要参数（用户id、旅游服务id）
     */
    @Insert("insert into t_collection values(#{uid},#{sid},#{date})")
    int insertCollection(@Param("uid") int uid,@Param("sid") int sid,@Param("date") String date);
}
