package util;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Date {

    public String dateTime(){
        Calendar calendar= Calendar.getInstance();
        SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String time=dateFormat.format(calendar.getTime());
        return time;
    }
}