package Web.Servlet;

import Pojo.Service;
import Pojo.User;
import Service.CollectionService;
import Pojo.Collection;
import Pojo.PageBean;
import com.alibaba.fastjson.JSON;

import javax.servlet.ServletException;
import javax.servlet.annotation.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;


@WebServlet("/CollectionServlet/*")
public class CollectionServlet extends BaseServlet {
    /**
     * 直接编写方法即可,例 public void insert(){}
     */
    private CollectionService collectionService = new CollectionService();

    // 创建service对象
    public void collectionShow(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int uid = Integer.parseInt(request.getParameter("uid"));
        List<Collection> collections = collectionService.collectionShow(uid);
        String jsonString = JSON.toJSONString(collections);
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);

    }

    public void collectionDelete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int serviceId = Integer.parseInt(request.getParameter("serviceId"));
        User user = (User) request.getSession().getAttribute("user");
        int uid = user.getUid();
        Service service = new Service();
        service.setService_id(serviceId);
        service.setUser_id(uid);
        System.out.println("servlet启动");
        collectionService.collectionDelete(service);
        response.getWriter().write("success");

    }

    public void ShowByPage(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int currentPage = Integer.parseInt(request.getParameter("currentPage"));
        int pageSize = Integer.parseInt(request.getParameter("pageSize"));
        User user = (User) request.getSession().getAttribute("user");
        int uid = user.getUid();
        PageBean<Collection> pageBean = collectionService.collectionSelectByPage(uid, currentPage, pageSize);
        String jsonString = JSON.toJSONString(pageBean);
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }

    public void Count(HttpServletRequest request, HttpServletResponse response) throws IOException {
        User user = (User) request.getSession().getAttribute("user");
        int uid = user.getUid();
        int count = collectionService.collectionCount(uid);
//        System.out.println(count);
        String jsonString = JSON.toJSONString(count);
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }

    /**
     * 用户新增收藏
     */
    public void insertCollection(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int i = 0;  //默认i未0，说明添加失败
        //        设置响应体
        response.setContentType("application/json;charset = UTF-8");
//        获取输入流
        PrintWriter writer = response.getWriter();
//        获取前端数据
        int sid = Integer.parseInt(request.getParameter("sid"));   //旅游服务id
        String date = request.getParameter("date");
        //判断当前用户是否登录
        User user = (User) request.getSession().getAttribute("user");
        if (user != null) {
            try {
                //用户已登录,可以进行收藏
                i = collectionService.insertCollection(user.getUid(), sid, date);
            } catch (Exception e) {
                //捕获异常
            }
            if (i == 1) {
                //添加成功，返回响应1
                writer.print(1);
            } else {
                //添加失败，i为默认值0，返回响应2.说明已收藏
                writer.print(2);
            }
        } else {
            //用户未登录，返回响应0
            writer.print(0);
        }
    }
}
