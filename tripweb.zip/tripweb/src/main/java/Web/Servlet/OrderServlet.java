package Web.Servlet;

import Pojo.PageBean;
import Pojo.User;
import Service.OrderService;
import Pojo.Order;
import com.alibaba.fastjson.JSON;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

@WebServlet("/OrderServlet/*")
public class OrderServlet extends BaseServlet {
    // 创建service对象
    private OrderService orderService = new OrderService();

    /**
     * 新增订单
     */
    public void insertOrder(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 设置响应体
        response.setContentType("application/json;charset = UTF-8");
        PrintWriter writer = response.getWriter();
        // 获取订单信息并封装
        Order newOrder = new Order(Integer.parseInt(request.getParameter("uid")),   //获取用户
                Integer.parseInt(request.getParameter("sid")),
                request.getParameter("orderDate"),
                Integer.parseInt(request.getParameter("amount")),
                Float.parseFloat(request.getParameter("total")));
        //校验订单信息
        System.out.println(newOrder);

        //执行Dao层的方法操作数据库
        int count = 0;
        try {
//           返回响应值，代表数据库更新的数据条目数，1则代表执行新增订单成功
            count = orderService.insertOrder(newOrder);
        }catch (Exception e){
            System.out.println("添加失败！");
        }
        if (count == 1) {
            //说明执行成功,返回响应条件
            System.out.println("添加成功！");
            writer.print("success");
        }else {
            //添加失败
            writer.print("error");
        }
    }

    /**
     * 在订单页面获取用户信息
     */
    public void getUserInfo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 设置响应体
        response.setContentType("application/json;charset = UTF-8");
        System.out.println("getUserInfo...");
//        获取当前登录的用户
        Object user = request.getSession().getAttribute("user");
        if(user!=null){
            System.out.println("获取的用户信息为：\n"+user);
            // 转换为JSON字符串
            String jsonStr = JSON.toJSONString(user);
            // 校验json字符串
            System.out.println(jsonStr);
            //返回数据给ajax请求
            PrintWriter writer = response.getWriter();
            writer.println(jsonStr);
        }else {
            System.out.println("获取登录用户信息失败！");
        }
    }

    /**
     * 在订单页面获取旅游服务信息
     */
    public void getServiceBySid(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 设置响应体
        response.setContentType("application/json;charset = UTF-8");
        System.out.println("getServiceBySid...");
        //获取当前旅游服务的id
        int sid = Integer.parseInt(request.getParameter("sid"));
        // 调用dao层方法获取旅游服务信息
        Map<String,Object> service = orderService.SelectServiceBySid(sid);
        // 旅游服务信息不为空
        if(service != null){
            String jsonStr = JSON.toJSONString(service);
            //校验json
            System.out.println("旅行服务json:  "+jsonStr);
            // 获取发送文件
            PrintWriter writer = response.getWriter();
            writer.println(jsonStr);
        }else {
            System.out.println("查询失败，不存在该旅游服务!");
        }
    }

    /**
     * -------------------------------------刘怀键
     */
    public void ShowByPage (HttpServletRequest request, HttpServletResponse response) throws IOException {
//        int uid = Integer.parseInt(request.getParameter("uid"));
        User u = (User) request.getSession().getAttribute("user");
        int uid = u.getUid();
        int currentPage = Integer.parseInt(request.getParameter("currentPage"));
        int pageSize = Integer.parseInt(request.getParameter("pageSize"));
        PageBean<Order> pageBean = orderService.SelectByPage(uid, currentPage, pageSize);
        String jsonString = JSON.toJSONString(pageBean);
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }
    public void orderDelete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int sid = Integer.parseInt(request.getParameter("sid"));
        User u = (User) request.getSession().getAttribute("user");
        int uid = u.getUid();
        Order order = new Order();
        order.setSid(sid);
        order.setUid(uid);
        orderService.orderDelete(order);
        response.getWriter().write("success");
    }

}
