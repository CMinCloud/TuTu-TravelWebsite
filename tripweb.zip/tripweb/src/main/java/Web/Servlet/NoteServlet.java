package Web.Servlet;

import Service.NoteService;
import Service.UserService;
import Pojo.*;
import com.alibaba.fastjson.JSON;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import util.Date;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@WebServlet("/NoteServlet/*")
public class NoteServlet extends BaseServlet{
    /**
     * 对客户端进行响应,直接编写方法即可
     */
    //创建service对象
    NoteService noteService = new NoteService();
    UserService userService=new UserService();
    Date date=new Date();

    /***
     *获取用户id
     * 根据用户id增添游记头----------------禁止删除--------------------
     */
    public void addNoteTitle( HttpServletRequest request,HttpServletResponse response ) throws Exception {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if(user!=null){
            int uid = user.getUid();
            String fn=null;//用uiid转换的图片名字
            String title=null;//游记标题
            String playdays=null;//游玩天数
            String recommend=null;//游记推荐信息
            String time=date.dateTime();/*游记的发布时间*/
            String note_img=null;/*游记头附属图片*/
            /*图片存放路径*/

            String relpath="/img/NoteModuleImg";
            String path=request.getRealPath(relpath);

            /*从noteTitleSend中获取表单的值*/
            /*设置字符编码，解决中文乱码问题*/
            request.setCharacterEncoding("utf-8");
            /*获取图片生成地址放到数据库里面*/

            DiskFileItemFactory diskFileItemFactory = new DiskFileItemFactory();/*创建文件处理工厂*/
            ServletFileUpload upload = new ServletFileUpload(diskFileItemFactory);/*处理上传的文件*/
            upload.setHeaderEncoding("UTF-8");/*设置文件上传编码*/
//
            /*获取表单里面的值*/
            try {
                List<FileItem> fileItems = upload.parseRequest(request);
                System.out.println(fileItems);
                for (FileItem item: fileItems) {
                    /*有可能是文件，有可能是普通文字*/
                    if(item.isFormField()){
                        /*如果是文字*/
                        String fieldName = item.getFieldName();
                        String value=item.getString("UTF-8");
                        System.out.println(fieldName);
                        if("title".equals(fieldName)){
                            title=value;
                            System.out.println(title);
                        }
                        if("days".equals(fieldName)){
                            playdays=value;
                        }
                        if("recommend".equals(fieldName)){
                            recommend=value;
                        }
                    }else {
                        /*如果是文件，也就是那张图片*/
                        /*获取图片后缀名*/
                        String format = item.getName().substring(item.getName().indexOf("."), item.getName().length());
                        /*图片命名*/
                        fn = UUID.randomUUID().toString().replaceAll("-", "") + format;
                        System.out.println("文件名是:"+fn);
                        note_img="NoteModuleImg/"+fn;
                        System.out.println("存入数据库的地址是："+note_img);
                        item.write(new File(path,fn));
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

//        note_img="NoteModuleImg/"+fn;/*这就是保存到数据库的相对路径*/
            Note note = new Note(title, uid, time, note_img, playdays, recommend);
            int count=noteService.addNoteTitle(note);
            if(count==1){
                System.out.println("添加成功");
            }
            /*重定向*/
            response.sendRedirect("/tripweb/noteModuleSend.html");
            /*请求转发*/
//        request.getRequestDispatcher("/noteModuleSend.html").forward(request, response);
        }else {
            response.sendRedirect("/tripweb/login.html");
        }



    }





    /*
     * 给正在发布的游记添加模块的方法---------------禁止删除--------------------
     * 找到当前游记表里面的最后一个id     selectLastNoteId()
     * 根据游记id添加对应的游记模块
     * */
    public void addNoteModule(HttpServletRequest request,HttpServletResponse response) throws IOException, FileUploadException, ServletException {
        String fn=null;    //用uiid转换的图片名
        String module_name=null;
        String content=null;
        int note_id;
        String module_img=null;

        //图片存放路径
        String relpath="/img/NoteModuleImg";
        String path=request.getRealPath(relpath);

        /*从noteTitleSend.html中获取表单的值*/
        /*设置字符编码，解决中文乱码问题*/
        request.setCharacterEncoding("utf-8");

        /*创建一个模块参数*/
        note_id= noteService.selectLastNoteId();

        /*获取图片生成地址存放到数据库里面*/
        DiskFileItemFactory diskFileItemFactory = new DiskFileItemFactory();/*创建文件处理工厂*/
        ServletFileUpload upload = new ServletFileUpload(diskFileItemFactory);/*处理上传的文件*/
        upload.setHeaderEncoding("UTF-8");/*设置上传文件编码*/
        /*获取表单里面的所有值*/
        try {
            List<FileItem> fileItems = upload.parseRequest(request);
            for (FileItem item:fileItems) {
                /*有可能是文件，也有可能是普通文字*/
                if(item.isFormField()){
                    /*如果是文字*/
                    String fieldName = item.getFieldName();
                    String value = item.getString("UTF-8");
                    if("ModuleName".equals(fieldName)){
                        module_name=value;
                    }
                    if("ModuleContent".equals(fieldName)){
                        content=value;
                    }
                }else {
                    /*如果是文件*/
                    /*获取图片后缀名*/
                    String format = item.getName().substring(item.getName().indexOf("."), item.getName().length());
                    /*图片命名*/
                    fn = UUID.randomUUID().toString().replaceAll("-", "") + format;
                    System.out.println("文件名是："+fn);/*文件名*/
                    /* fn 可能是这样的：c:\abc\de\tt\fish.jpg*/
                    item.write(new File(path,fn));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        module_img="NoteModuleImg/"+fn;
        /*保存数据库的是相对路径*/
        System.out.println("数据库存放的相对路径"+module_img);
        NoteModule noteModule = new NoteModule(module_name, content, note_id, module_img);


        /*调用Service里面的方法将游记模块添加到对应的游记模块里面*/
        int count = noteService.addNoteModule(noteModule);
        if(count==1){
            System.out.println("添加成功~");
        }

    }




    public void addNoteModule1(HttpServletRequest request,HttpServletResponse response) throws IOException, FileUploadException, ServletException {
        addNoteModule(request,response);
        response.sendRedirect("/tripweb/noteModuleSend.html");
    }



    public void addNoteModule2(HttpServletRequest request,HttpServletResponse response) throws IOException, FileUploadException, ServletException {
        addNoteModule(request,response);
        response.sendRedirect("/tripweb/noteModuleCsssssss.html");
    }







    /*
     获取所有的游记id集合---------------禁止删除--------------------
     * 根据游记id  在游记表里面来查找出对应的游记对象
     * */
//    NoteServlet/NoteDetails
    public void NoteDetails(HttpServletRequest request,HttpServletResponse response) throws IOException {

        request.setCharacterEncoding("utf-8");/*设置接受数据的编码格式*/
        response.setContentType("text/json;charset=utf-8");
        response.setCharacterEncoding("utf-8");/*设置响应数据的编码格式*/

        ArrayList<NoteModuleDetail> NoteArray=new ArrayList<NoteModuleDetail>();
        /*获取游记表里面的所有游记id的集合*/
        ArrayList<Integer> NoteIds= noteService.NoteIdList();
        /*循环遍历游记id*/
        for (int nid:NoteIds) {
            /*根据游记id查找出对应的user_id*/
            Integer userId = noteService.UserId(nid);
            /*根据用户id获取对应的用户对象*/
            User user = noteService.UserMessage(userId);
            /*根据游记id,在游记表里面查找出对应的游记对象*/
            Note note = noteService.NoteDetails(nid);

            NoteModuleDetail noteModuleDetail = new NoteModuleDetail(note.getNote_id(), note.getNote_title(), note.getUser_id(), note.getNote_date(), note.getNote_img(), note.getComment_like(), note.getPlaydays(), note.getRecommend(),
                    user.getUsername(), user.getUserImg());
            NoteArray.add(noteModuleDetail);
        }
        String noteArray = JSON.toJSONString(NoteArray);
        System.out.println(noteArray);
        System.out.println("----------------------------------------------");
        response.getWriter().print(noteArray);
        response.getWriter().flush();
        response.getWriter().close();

    }





    //-------NoteDetailTitle()方法--------禁止删除--------------------

    public void NoteDetailTitle(HttpServletRequest request,HttpServletResponse response) throws IOException {


        request.setCharacterEncoding("utf-8");/*设置接受数据的编码格式*/
        response.setContentType("text/json;charset=utf-8");
        response.setCharacterEncoding("utf-8");/*设置响应数据的编码格式*/
        int note_id = Integer.parseInt(request.getParameter("note_id"));

        /*循环遍历游记id*/

        /*根据游记id查找出对应的user_id*/
        Integer userId = noteService.UserId(note_id);
        /*根据用户id获取对应的用户对象*/
        User user = noteService.UserMessage(userId);
        /*根据游记id,在游记表里面查找出对应的游记对象*/
        Note note = noteService.NoteDetails(note_id);

        NoteModuleDetail noteModuleDetail = new NoteModuleDetail(note.getNote_id(), note.getNote_title(), note.getUser_id(), note.getNote_date(), note.getNote_img(), note.getComment_like(), note.getPlaydays(), note.getRecommend(),
                user.getUsername(), user.getUserImg());
        String noteArray = JSON.toJSONString(noteModuleDetail);

        System.out.println(noteArray);
        System.out.println("----------------------------------------------");
        response.getWriter().print(noteArray);

        response.getWriter().flush();
        response.getWriter().close();

    }




    /*游记模块分页展示*/
//    NoteServlet/pageQuery
    public void pageQuery(HttpServletRequest request,HttpServletResponse response) throws IOException {

        request.setCharacterEncoding("utf-8");/*设置接受数据的编码格式*/
        response.setContentType("text/json;charset=utf-8");
        response.setCharacterEncoding("utf-8");/*设置响应数据的编码格式*/


        /*接受前端传来的参数*/
        String currentPageStr = request.getParameter("currentPage");
        String pageSizeStr = request.getParameter("pageSize");
        String note_titleStr = request.getParameter("note_title");

        /*处理参数*/
        int currentPage;/*当前页码，如果不传递，默认为第一页*/
        if(currentPageStr!=null&&currentPageStr.length()>0){
            currentPage= Integer.parseInt(currentPageStr);
        }
        else {
            currentPage=1;
        }

        int pageSize=0;/*每页显示条数，如果不传递，默认每页显示3条记录*/
        if(pageSizeStr!=null&&pageSizeStr.length()>0){
            pageSize=Integer.parseInt(pageSizeStr);
        }else {
            pageSize=4;
        }

        /*每页显示条数，如果不传递，默认每页显示4条记录*/
        String note_title;
        if(note_titleStr!=null&&note_titleStr.length()>0){
            note_title = URLDecoder.decode(note_titleStr,"UTF-8");
        }else {
            note_title=null;
        }
        System.out.println("--------------------");
        System.out.println(note_title);
        System.out.println("-------------------");

        /*调用Service查询PageBean对象  */
        PageBean<NoteModuleDetail> pb = noteService.pageQuery(note_title,currentPage, pageSize);

        /*将对象序列化为json返回*/
        String jsonString = JSON.toJSONString(pb);
        System.out.println("-----------------------------------------");
        System.out.println(jsonString);
        System.out.println("-----------------------------------------");
        response.getWriter().print(jsonString);
        response.getWriter().flush();
        response.getWriter().close();
    }






    /*
     * 游记详情页面的相关展示
     * 根据
     * ArrayList<Integer> NoteIds(@Param("uid") int uid);方法查询出游记id的集合
     * 遍历游记id
     * 根据游记id在游记模块表里面查询出模块对象集合
     *
     * 在页面上点开某个模块的时候，要传过去两个参数( 用户id,游记id ),进行相关页面展示
     *
     * */
//    NoteServlet/NoteModuleDetails
    public void  NoteModuleDetails(HttpServletRequest request,HttpServletResponse response) throws IOException {
        /*获取游记note_id*/
        String note_id = request.getParameter("note_id");
        int noteId = Integer.parseInt(note_id);

        request.setCharacterEncoding("utf-8");/*设置接受数据的编码格式*/
        response.setContentType("text/json;charset=utf-8");
        response.setCharacterEncoding("utf-8");/*设置响应数据的编码格式*/
        /*创建一个模块集合对象*/
        ArrayList<NoteModule> noteModules = new ArrayList<NoteModule>();

        /*根据游记id获取游记模块表里面的所有游记模块的id集合*/
        ArrayList<Integer> moduleIds = noteService.ModuleIds(noteId);
        /*遍历模块id集合，查询出模块表里面的每一个模块对象，将这些模块对象添加到对象集合里面*/
        for (Integer moduleId:moduleIds) {
            /*根据模块id查询出对应的模块对象*/
            NoteModule module = noteService.Module(moduleId);
            noteModules.add(module);
        }
        String noteArray = JSON.toJSONString(noteModules);

        System.out.println(noteArray);
        System.out.println("----------------------------------------------");
        response.getWriter().print(noteArray);

        response.getWriter().flush();
        response.getWriter().close();
    }



    /*游记取消发送*/
//    /tripweb/NoteServlet/deleteModule
    public void deleteModule1(HttpServletRequest request,HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("utf-8");/*设置接受数据的编码格式*/
        response.setContentType("text/json;charset=utf-8");
        response.setCharacterEncoding("utf-8");/*设置响应数据的编码格式*/

        /*查询游记表里面的最后一个游记id*/
        int noteId = noteService.selectLastNoteId();
        /*删除游记*/
        noteService.deleteModule(noteId);
        /*重定向到游记模块浏览页面*/
        response.sendRedirect("/tripweb/noteModuleCsssssss.html");

    }


    /*不想看：删除对应游记*/
//    /tripweb/NoteServlet/deleteModule2
    public void deleteModule2(HttpServletRequest request,HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("utf-8");/*设置接受数据的编码格式*/
        response.setContentType("text/json;charset=utf-8");
        response.setCharacterEncoding("utf-8");/*设置响应数据的编码格式*/

        int note_id = Integer.parseInt(request.getParameter("note_id"));
        /*删除游记*/
        noteService.deleteModule(note_id);

    }



    /*游记发布检验，看是否登录*/
//  /tripweb/NoteServlet/sendCs
    public void sendCs(HttpServletRequest request,HttpServletResponse response) throws IOException {

        request.setCharacterEncoding("utf-8");/*设置接受数据的编码格式*/
        response.setContentType("text/json;charset=utf-8");
        response.setCharacterEncoding("utf-8");/*设置响应数据的编码格式*/
        String flag="yes";
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if(user!=null){
            flag="yes";
        }else {
            flag="no";
        }
        String jsonStr = JSON.toJSONString(flag);
        System.out.println(jsonStr);
        response.getWriter().print(jsonStr);
        response.getWriter().flush();
        response.getWriter().close();
    }

    /**
     * 刘怀键------------------------------------------------------------
     */
    public void ShowByPage (HttpServletRequest request, HttpServletResponse response) throws IOException {
        User user = (User) request.getSession().getAttribute("user");
        int uid = user.getUid();
        System.out.println(user.getUsername());
        int currentPage = Integer.parseInt(request.getParameter("currentPage"));
        int pageSize = Integer.parseInt(request.getParameter("pageSize"));
        PageBean<Note> pageBean = null;
        if (user.getUsername().equals("admin")) {
            System.out.println("执行admin的方法");
            pageBean = noteService.noteAllSelectByPage(currentPage,pageSize);
        } else {
            System.out.println("执行用户方法");
            pageBean = noteService.noteSelectByPage(uid, currentPage, pageSize);
        }
        String jsonString = JSON.toJSONString(pageBean);
        System.out.println(jsonString);
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }
    public void noteDelete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int nid = Integer.parseInt(request.getParameter("nid"));
        noteService.noteDelete(nid);
        response.getWriter().write("success");
    }
    public void Count(HttpServletRequest request, HttpServletResponse response) throws IOException {
        User user = (User) request.getSession().getAttribute("user");
        int uid = user.getUid();
        int count = noteService.Count(uid);
        System.out.println("note"+count);
        String jsonString = JSON.toJSONString(count);
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }



}
