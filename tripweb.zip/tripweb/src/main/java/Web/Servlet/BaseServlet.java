package Web.Servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;


/**
 * 自定义Servlet，重定义service方法
 * 使用请求路径进行方法分发，替换HttpServlet的根据请求方式进行分发
 */

public class BaseServlet extends HttpServlet {

    // 根据请求路径来进行方法分发
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 1.获取请求路径
        String uri = req.getRequestURI();
        // 2.获取最后一段路径，方法名
        int index = uri.lastIndexOf('/');
        String methodName = uri.substring(index + 1); // 获取最后的方法名
        System.out.println("执行方法："+methodName);
        // 3.执行方法
        // 3.1 获取Servlet 字节码对象 Class
        Class<? extends BaseServlet> cls = this.getClass();

        // 3.2 获取Method方法
        try {
            Method method = cls.getMethod(methodName, HttpServletRequest.class, HttpServletResponse.class);
            try {
                // 3.3 执行方法
                /*通过反射包下的Method类调用invoke方法，调用我们所提供的方法以及调用方法的参数来完成动态调用。
                    通过填写路径参数，就可以直接调用方法了！
                * */
                method.invoke(this,req,resp);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
        } catch (NoSuchMethodException e) {
//            找不到路径所填写的方法
            e.printStackTrace();
        }
    }
}
