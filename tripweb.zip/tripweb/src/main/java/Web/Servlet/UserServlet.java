package Web.Servlet;

import Dao.Mapper.UserMapper;
import Pojo.Safe;
import Pojo.User;
import Service.UserService;
import com.alibaba.fastjson.JSON;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import util.SqlSessionFactoryUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.*;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@WebServlet("/UserServlet/*")
public class UserServlet extends BaseServlet {

    // 创建service对象
    UserService userService = new UserService();
    SqlSessionFactory factory = SqlSessionFactoryUtils.getSqlSessionFactory();

    /**
     * 用户登录处理
     */
    public void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 设置响应体
        response.setContentType("application/json;charset = UTF-8");
        //接收前端响应的参数
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String remember = request.getParameter("remember");
        System.out.println("servlet接收的username:" + username + ",password:" + password);
        PrintWriter writer = response.getWriter();
        //执行Dao层的方法操作数据库
        User user = userService.SelectIdByLoginInfo(username, password);
        if (user != null) {
            System.out.println("登录用户信息为：" + user);
            //判断用户是否勾选记住我
            if ("1".equals(remember)) {//勾选了记住我
                System.out.println("勾选了记住我");
                //创建cookie保存到浏览器中，设置cookie存活时间为7天：60*60*24*7
                Cookie c_username = new Cookie("username", username);
                Cookie c_password = new Cookie("password", password);
                c_username.setMaxAge(60 * 60 * 24 * 7);
                c_password.setMaxAge(60 * 60 * 24 * 7);
//                设置cookie适用范围
                c_username.setPath("/");
                c_password.setPath("/");
//                添加cookie
                response.addCookie(c_username);
                response.addCookie(c_password);
            }
            /**
             * 将登录信息储存在session域中，以共多次请求使用
             */
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            //发送响应信息作判断
            writer.print(1);
        } else {
            System.out.println("Servlet登陆失败！");
            writer.print(0);
        }
    }

    /**
     * 用户退出登录
     */
    public void exit(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        设置响应体
        response.setContentType("application/json;charset = UTF-8");
//        获取输入流
        PrintWriter writer = response.getWriter();
        if (request.getSession().getAttribute("user") != null) {
            //有用户登录数据，进行删除
            request.getSession().removeAttribute("user");
            // 删除用户成功，向前端响应1
            writer.print(1);
        } else {
//                用户尚未登录,向前端响应0
            writer.print(0);
        }
    }

    /**
     * 找回密码
     * 用户密保问题验证
     */
    public void getSecretByPhone(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //        设置响应体
        response.setContentType("application/json;charset = UTF-8");
//        获取输入流
        PrintWriter writer = response.getWriter();
        //获取前端的手机号
        String phone = request.getParameter("phone");
        //对用户手机号进行校验，如果返回值为1则说明该用户确实绑定了手机账号
        if (userService.CountUserByPhone(phone) == 1) {
//            根据手机号查询用户密保信息
            ArrayList<Map<String, String>> secrets = userService.getSecretByPhone(phone);
            if (secrets.size() != 0) {
                //用户设置了密保，将密保信息以json形式返回
                String jsonStr = JSON.toJSONString(secrets);
                writer.println(jsonStr);
            } else {
//                用户未设置密保问题,返回判定信息
                writer.print(2);
            }
        } else {
            //手机号错误，返回对应信息
            writer.print(1);
        }
    }

    /**
     *  重置密码
     */
    public void SetNewPassword(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //        设置响应体
        response.setContentType("application/json;charset = UTF-8");
//        获取输入流
        PrintWriter writer = response.getWriter();
        //获取用户uid和新密码
        int uid = Integer.parseInt(request.getParameter("uid"));
        String newPasswd = request.getParameter("newPassword");
//        调用service层方法修改密码
        if (userService.SetNewPassword(uid, newPasswd) == 1) {
            //修改成功,返回判断参数
            writer.print(1);
        } else {
            //修改失败
            writer.print(0);
        }
    }

    /**
     * 刘怀键--------------------------------------------------------
     */
    public void register(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String phone = request.getParameter("phone");
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setPhone(phone);

        System.out.println(user);
        boolean flag = userService.regist(user);
        if (flag) {
            response.getWriter().write("true");
        } else {
            response.getWriter().write("false");
        }
    }

    public void change(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {

        request.setCharacterEncoding("UTF-8");
        String name = request.getParameter("name");
        System.out.println(name);
        String sex = request.getParameter("sex");
        System.out.println(sex);
        if (sex.equals("女")) {
            sex = "1";
        } else {
            sex = "0";
        }
        System.out.println(sex);
        String introduction = request.getParameter("introduction");
        String phone = request.getParameter("phone");
        User user = new User();
        user.setDetails(introduction);
        user.setPhone(phone);
        user.setRealName(name);
        user.setSex(sex);
        user.setUid(1);
        System.out.println(user);
        userService.change(user);
    }

    /*寻找个人资料*/
    public void userShow(HttpServletRequest request, HttpServletResponse response) throws IOException {
        User u = (User) request.getSession().getAttribute("user");
        int uid1 = u.getUid();
        System.out.println(uid1);
//        int uid = Integer.parseInt(request.getParameter("uid"));
        User user = userService.userShow(uid1);
        String jsonString = JSON.toJSONString(user);
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }

    public void reset(HttpServletRequest request, HttpServletResponse response) throws IOException {
        /*oldPass=12345&newPass=123456qwe&checkPass=123456qwe*/
        String newPass = request.getParameter("newPass");
        String oldPass = request.getParameter("oldPass");
        System.out.println(oldPass);
        User user = new User();
        user.setPassword(oldPass);
        user.setNewPass(newPass);
        user.setUid(1);
        boolean flag = userService.reset(user);
        if (flag) {
            response.getWriter().write("true");
        } else {
            response.getWriter().write("false");
        }
    }
    public void addSafe(HttpServletRequest request , HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        System.out.println("执行safe");
        User user = (User) request.getSession().getAttribute("user");
        List<Safe> list = new ArrayList<>();

        for(int i = 1 ; i<=3 ; i++){
            Safe safe = new Safe();
            safe.setUid(user.getUid());
            safe.setQuestion(request.getParameter("qs"+i));
            safe.setAnswer(request.getParameter("as"+i));
            System.out.println("uid为"+safe.getUid()+"qs为"+safe.getQuestion()+"as为"+safe.getAnswer());
            list.add(safe);
        }
        System.out.println(list);
        if(userService.addSafe(list)){
            response.getWriter().write("true");
        }else{
            response.getWriter().write("false");
        }
    }


}


