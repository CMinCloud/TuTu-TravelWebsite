package Web.Servlet;

import javax.servlet.annotation.*;

@WebServlet("/PictureServlet/*")
public class PictureServlet extends BaseServlet {
    /**
     * 直接编写方法即可,例 public void insert(){}
     */

}
