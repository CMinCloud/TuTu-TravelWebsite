package Web.Servlet;

import Pojo.*;
import Service.ServiceService;
import com.alibaba.fastjson.JSON;

import javax.servlet.annotation.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLDecoder;


@WebServlet("/ServiceServlet/*")
public class ServiceServlet extends BaseServlet {
    ServiceService serviceService = new ServiceService();
    /**
     * 直接编写方法即可,例 public void insert(){}
     */
    /*该方法用于渲染景点模块展示页面*/
//    ServiceServlet/serviceModules
    public void serviceModules(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("utf-8");/*设置接受数据的编码格式*/
        response.setContentType("text/json;charset=utf-8");
        response.setCharacterEncoding("utf-8");/*设置响应数据的编码格式*/
        /*接受前端传来的参数*/

        String currentPageStr = request.getParameter("currentPage");
        String pageSizeStr = request.getParameter("pageSize");
        String service_name = request.getParameter("service_name");
        /*处理参数*/
        int currentPage;/*当前页码，如果不传递，默认为第一页*/
        if(currentPageStr!=null&&currentPageStr.length()>0){
            currentPage= Integer.parseInt(currentPageStr);
        }
        else {
            currentPage=1;
        }

        int pageSize=0;/*每页显示条数，如果不传递，默认每页显示3条记录*/
        if(pageSizeStr!=null&&pageSizeStr.length()>0){
            pageSize=Integer.parseInt(pageSizeStr);
        }else {
            pageSize=6;/*不能改*****/
        }

        /*每页显示条数，如果不传递，默认每页显示4条记录*/
        String serviceNameStr;
        if(service_name!=null&&service_name.length()>0){
            serviceNameStr = URLDecoder.decode(service_name,"UTF-8");
        }else {
            serviceNameStr=null;
        }

        System.out.println("--------------------");
        System.out.println(serviceNameStr);
        System.out.println("-------------------");

        /* 调用ServiceService里面的pageQuery方法获取pb( 对象（分页相关数据，集合对象(对象里面有图片集合) ) */
        PageBean<Service> pb = serviceService.pageQuery(serviceNameStr, currentPage, pageSize);
        String serviceArray = JSON.toJSONString(pb);

        System.out.println(serviceArray);
        System.out.println("----------------------------------------------");
        response.getWriter().print(serviceArray);

        response.getWriter().flush();
        response.getWriter().close();

    }



    /*根据service_id去找到对应的service详细信息*/
//    ServiceServlet/serviceDetail
    public void serviceDetail(HttpServletRequest request,HttpServletResponse response) throws IOException {

        // 设置响应体
        response.setContentType("application/json;charset = UTF-8");
        request.setCharacterEncoding("utf-8");/*设置接受数据的编码格式*/
        response.setContentType("text/json;charset=utf-8");
        response.setCharacterEncoding("utf-8");/*设置响应数据的编码格式*/
        int service_id = Integer.parseInt(request.getParameter("service_id"));

        System.out.println(service_id);


        Service service = serviceService.serviceDetail(service_id);

        String serviceArray = JSON.toJSONString(service);

        System.out.println(serviceArray);
        System.out.println("----------------------------------------------");
        response.getWriter().print(serviceArray);

        response.getWriter().flush();
        response.getWriter().close();

    }


}
