package Web.Servlet;

import Pojo.PageBean;
import Service.CommentService;
import Pojo.User;
import com.alibaba.fastjson.JSON;

import javax.servlet.ServletException;
import javax.servlet.annotation.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


@WebServlet("/CommentServlet/*")
public class CommentServlet extends BaseServlet {
    // 创建service对象
    CommentService commentService = new CommentService();

    /**
     * 新增评论
     */
    public void insertComment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//         设置响应体
        response.setContentType("application/json;charset = UTF-8");
        PrintWriter writer = response.getWriter();
//         初始化map
        Map<String, Object> map = new HashMap<String, Object>();
//         获取参数并封装为Map对象
        String type = request.getParameter("type");
        String date = request.getParameter("date");
        String content = request.getParameter("content");
//         获取当前登录用户
        User user = (User) request.getSession().getAttribute("user");
        if (user != null) {
            // 用户已登录，可以发表评论
            map.put("date", date);
            map.put("type", type);
            map.put("content", content);
            map.put("uid", user.getUid());
            int i = 0;
            if (Integer.parseInt(type) == 1) {
//                获取旅游服务id
                int sid = Integer.parseInt(request.getParameter("sid"));
                map.put("sid", sid);
                //新增旅游服务评论
                i = commentService.InsertServiceComment(map);
            } else if (Integer.parseInt(type) == 2) {
//                获取游记评论id
                int nid = Integer.parseInt(request.getParameter("nid"));
                map.put("nid", nid);
//                新增游记评论
                i = commentService.InsertNoteComment(map);
            }
//              调用dao方法进行添加尝试
            if (i == 1) {
                //添加成功
                writer.write("success");
            }
        } else {
            // 用户未登录
            writer.write("error");
            System.out.println("用户登陆失败~");
        }
    }

    /**
     * 获取评论列表
     */
    public void getCommentList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 设置响应体
        response.setContentType("application/json;charset = UTF-8");

        int sid = 0, nid = 0;
        try {
//            获取旅游服务id
            sid = Integer.parseInt(request.getParameter("sid"));
        } catch (Exception e) {/*捕获null值*/}
        try {
//            获取游记id
            nid = Integer.parseInt(request.getParameter("nid"));
        } catch (Exception e) {/*捕获null值*/}
//        校验
        System.out.println("获取的sid为：" + sid + ",获取的nid为：" + nid);
        //初始化map
        ArrayList<Map<String, Object>> comments = null;
        //调用service层方法查询评论
        comments = commentService.selectComments(sid, nid);
        System.out.println(comments);   //检验

        //说明调用了dao层方法获取了数据
        if (comments != null) {
            String jsonStr = JSON.toJSONString(comments);
            //校验json
            System.out.println(jsonStr);
            //反馈信息
            PrintWriter writer = response.getWriter();
            writer.println(jsonStr);
        }
    }

    /**
     * 分页查询评论列表（旅游服务评论）
     */
    public void selectCommentsByPage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 设置响应体
        response.setContentType("application/json;charset = UTF-8");
//        初始化数据
        int sid = 0;            //旅游服务号
        int nid = 0;            //游记号
        int currentPage = 0;     //当前页号
        int pageSize = 0;        //一页所显示的数据条目数
//        获取sid或nid
        try {
            sid = Integer.parseInt(request.getParameter("sid"));
        } catch (Exception e) {/*捕获null值*/}
        try {
            nid = Integer.parseInt(request.getParameter("nid"));
        } catch (Exception e) {/*捕获null值*/}
        //获取当前页码数和页显示条数
        currentPage = Integer.parseInt(request.getParameter("currentPage"));
        pageSize = Integer.parseInt(request.getParameter("pageSize"));

//        获取评论列表所需数据(评论列表,总评论数)
        PageBean<Map<String, Object>> CommentsInfo = commentService.selectCommentsByPage(sid, nid, currentPage, pageSize);
        //转化为json字符串
        String jsonStr = JSON.toJSONString(CommentsInfo);
//        校验json
        System.out.println(jsonStr);
//        反馈信息（json数据）
        PrintWriter writer = response.getWriter();
        writer.println(jsonStr);
    }

    /**
     * 判定是否管理员登录
     */
    public void adminJudge(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 设置响应体和输出流
        response.setContentType("application/json;charset = UTF-8");
        PrintWriter writer = response.getWriter();
        // 获取当前登录用户
        User user = (User) request.getSession().getAttribute("user");
        if (user != null && user.getUsername().equals("admin")) {
            //确认为管理员登录,响应判定字段1
            writer.print(1);
        } else {
            //管理员未登录,响应判定字段0
            writer.print(0);
        }
    }


    /**
     * 删除评论
     */
    public void deleteComment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 设置响应体
        response.setContentType("application/json;charset = UTF-8");
        //获取目标评论id
        int cid = Integer.parseInt(request.getParameter("cid"));
        //执行service方法删除该评论
        int flag = commentService.DeleteCommentByCid(cid);
        //获取输出流
        PrintWriter writer = response.getWriter();
        if (flag == 1) {
            //删除成功,响应判定字段1
            System.out.println("评论删除成功,id:" + cid);
            writer.print(1);
        } else {
            //删除失败,响应判定字段0
            System.out.println("评论删除失败,id:" + cid);
            writer.print(0);
        }
    }
}
